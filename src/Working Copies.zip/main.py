import os
import sys
import logging

from dotenv import load_dotenv
from flask import Flask, render_template, request, jsonify

import os
import sys

# Add the src folder to the system path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import logging
from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv
from src.utils import extract_text_from_pdf  # This will now work
from src.rag import process_text, create_qa_chain

# Set up the Flask app and explicitly set the templates folder
app = Flask(__name__, template_folder=os.path.join(os.path.dirname(__file__), '../templates'))

# Force reload of environment variables
load_dotenv(override=True)  # This forces .env to overwrite system variables

api_key = os.getenv("OPENAI_API_KEY")
if api_key:
    print(f'✅ API Key Loaded: {api_key[:5]}**********')
else:
    print('❌ OPENAI_API_KEY not found in .env file or not set')


# Set up logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

# Load environment variables
try:
    load_dotenv()
    logging.info('Environment variables loaded successfully')
except Exception as e:
    logging.error(f'Error loading environment variables: {e}')

# Global variables to hold the vector store and QA chain
vector_store = None
qa_chain = None

def initialize_rag_system():
    """Load the PDF files from the data folder and create the QA chain."""
    global vector_store, qa_chain
    try:
        logging.info('Initializing RAG system...')

        data_folder = os.path.join(os.path.dirname(__file__), '../data')
        files = [f for f in os.listdir(data_folder) if f.endswith('.pdf')]
        logging.info(f'Files found in data folder: {files}')  # Log the files in the data folder

        if not files:
            logging.warning('No PDF files found in the data folder. Skipping initialization.')
            return

        file_path = os.path.join(data_folder, files[0])  # Pick the first PDF in the folder
        logging.info(f'Processing PDF file: {file_path}')

        resume_text = extract_text_from_pdf(file_path)
        logging.info('Text successfully extracted from the PDF')

        vector_store = process_text(resume_text)
        logging.info('Text successfully embedded and stored in vector store')

        qa_chain = create_qa_chain(vector_store)
        if qa_chain is not None:
            logging.info('QA chain successfully created')

    except Exception as e:
        logging.error(f'Error initializing RAG system: {e}')

@app.route('/')
def index():
    try:
        logging.info('Serving index.html page')
        return render_template('index.html')
    except Exception as e:
        logging.error(f'Error rendering index.html: {e}')
        return f"Error loading page: {e}", 500

@app.route('/ask', methods=['POST'])
def ask_question():
    """Handles user questions and returns an AI response."""
    try:
        question = request.json.get('question')
        logging.info(f'Received question from frontend: {question}')
        if not question:
            logging.error('No question received in request')
            return jsonify({"error": "No question received"}), 400
    except Exception as e:
        logging.error(f'Error getting question from request: {e}')
        return jsonify({"error": "Invalid question format"}), 400

    try:
        if qa_chain is None:
            logging.error('QA chain was not created. Trying to reinitialize.')
            initialize_rag_system()
            logging.error('QA chain is not initialized')
            return jsonify({"error": "QA chain is not initialized"}), 500
        
        response = qa_chain.run(question)
        logging.info(f'Successfully generated response: {response}')
        return jsonify({"response": response})
    except Exception as e:
        logging.error(f'Error generating response: {e}')
        return jsonify({"error": "Failed to generate response"}), 500
    
try:
    vector_store = process_text(resume_text)
    logging.info('Text successfully embedded and stored in vector store')

    if vector_store is None:
        logging.error('Vector store is None. Check if FAISS was created successfully.')
    else:
        logging.info('Vector store successfully created')

    qa_chain = create_qa_chain(vector_store)
    if qa_chain is not None:
        logging.info('QA chain successfully created')
    else:
        logging.error('QA chain is None after creation. Check if ChatOpenAI was initialized properly.')

except Exception as e:
    logging.error(f'Error initializing RAG system: {e}')



if __name__ == '__main__':
    logging.info('Starting Flask app on 0.0.0.0:5002')
    initialize_rag_system()  # Automatically load and process files from the data folder
    app.run(host="0.0.0.0", port=5002, debug=True)
